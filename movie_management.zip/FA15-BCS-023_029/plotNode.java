
public class plotNode {
String word;
movies_linkedlist m;
int height;
plotNode left;
plotNode right;

}
