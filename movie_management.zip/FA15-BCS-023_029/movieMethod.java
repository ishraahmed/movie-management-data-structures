import java.util.ArrayList;
import java.util.List;

public class movieMethod {
	List<movieNode> mn ;
	List<movieNode> mn1 ;
	movieMethod(){
		mn = new ArrayList<movieNode>();
		mn1 = new ArrayList<movieNode>();
	}
	public void inserdata(){
		reading red=new  reading();
	}
	hashmovie h=reading.h;
	
public void searchTitle(String movie){
	movieAvlNode mvl=h.search(movie);
	System.out.println(mvl.data.color);
	System.out.println(mvl.data.director_Name.name);
	System.out.println(mvl.data.num_critic_for_reviews);
	System.out.println(mvl.data.duration);
	System.out.println(mvl.data.director_fb_likes);
	System.out.println(mvl.data.actor_3_fb_likes);
	System.out.println(mvl.data.actor_2.name);
	System.out.println(mvl.data.actor_1_fb_likes);
	mvl.data.genres.printList();
	System.out.println(mvl.data.actor_1.name);
	System.out.println(mvl.data.movie_title);
	System.out.println(mvl.data.actor_1_fb_likes);

}
public void searchgenre(String genre){
	genres_linkedlist gll=reading.gl;
	genresNode gn=gll.findKey(genre);
	movies_linkedlist m=gn.m;
	System.out.println("movie for genre "+genre);
	m.printList();
}

public void searchActor(String actor)
{
hashActor an=reading.ha;	
actorNode ac=an.search(actor);
ac.list.printList();
}
public void searchDirector(String director){
	hashdirector hd=reading.hd;
	directorNode dn=hd.search(director);
	dn.list.printList();
}
public movieNode searchDirectorView(String director){
	hashdirector hd=reading.hd;
	directorNode dn=hd.search(director);
	movieNode m=dn.list.head;
	return m;
}
public void searchyear(int year){
	hashmovie h=reading.h;
	int s=h.table_size;
	for(int i=0;i<s;i++){
	h.arr[i].traverseByYear(year);
	}
}
public  List<movieNode> searchyearView(int year){
	hashmovie h=reading.h;
	int s=h.table_size;
	for(int i=0;i<s;i++){
	traverseByYearView(h.arr[i].root,year);
}
	return mn;
}
public  List<movieNode> searchRatingView(double min,double max){
	hashmovie h=reading.h;
	int s=h.table_size;
	for(int i=0;i<s;i++){
	traverseByRatingView(h.arr[i].root,min,max);
}
	return mn1;
}
void traverseByRatingView(movieAvlNode node,double min,double max)
{
    if (node == null)
        return;
   // System.out.println("ye"+node.data.title_year);
if(node.data.idmb_score>=min&&node.data.idmb_score<=max){
    mn1.add(node.data);
}
    traverseByRatingView(node.left,min,max);

    traverseByRatingView(node.right,min,max);
}

public void traverseByYearView(movieAvlNode node,int y)
{
    if (node == null)
        return;

if(node.data.title_year==y){
    mn.add(node.data);
}
    traverseByYearView(node.left,y);

    traverseByYearView(node.right,y);
}
public void searchrating(double min,double max){
	hashmovie h=reading.h;
	int s=h.table_size;
	for(int i=0;i<s;i++){
	h.arr[i].traverseByRating(min,max);}
}

public movieNode searchgenreview(String genre){
	genres_linkedlist gll=reading.gl;
	genresNode gn=gll.findKey(genre);
	movies_linkedlist m=gn.m;
	return m.head;
}
}
