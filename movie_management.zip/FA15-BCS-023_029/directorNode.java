
public class directorNode {
String name;
movies_linkedlist list;
int height;
directorNode left, right;


}
/*(String col,directorNode d_n,int num_c_r,int dur,int direc_fb_likes,int act_3_fb_likes,
 * actorNode actor2,int act1_fb_likes,String gros,actorNode actor1,String m_t,int n_v_u,
 * int c_t_fb_likes,actorNode actor3,int f_n_i_p,String m_idmb_link,
 * int n_u_for_reviews,String lang,String coun,String c_r,
		String bud,int t_y,int act2_fb_likes,int i_s,int a_r,int m_f_likes)*/  
/*/*mov=new movieNode(abc[0],direc,0,dur,Integer.parseInt(abc[4]),
Integer.parseInt(abc[5]),act2,Integer.parseInt(abc[7]),abc[8],act3,abc[11],
Integer.parseInt(abc[12]),Integer.parseInt(abc[13]),
act1,Integer.parseInt(abc[15]),
abc[16],Integer.parseInt(abc[17]),abc[18],
abc[19],abc[21],abc[22],Integer.parseInt(abc[23]),
Integer.parseInt(abc[24]),Integer.parseInt(abc[25]),Integer.parseInt(abc[26]),
Integer.parseInt(abc[27]));*/
            	   //System.out.print(abc[i]+"  ||   ");
            	 /*  if(i==0)
   color=abc[i];
            	   else if(i==1)
            	   
            	direc=new directorNode(null,abc[i]);	   
            	   
            	   else if(i==2){
            		   System.out.println(abc[i]);
            		   num_critic_for_reviews=Integer.valueOf(abc[i]);
            		   }
            	   
            	   else if(i==3)
       duration=Integer.valueOf(abc[i]);
            	   
            	   else if(i==4)
            		   director_fb_likes=Integer.valueOf(abc[i]);
            	   
            	   else if(i==5)
            		actor_3_fb_likes=Integer.valueOf(abc[i]);
            	   else if(i==6){
            		   act2=new actorNode();
            		   act2.name=abc[i];}
            	   else if(i==7)
            		   actor_1_fb_likes=Integer.valueOf(abc[i]);
            	   else if(i==8)
            		   gross=abc[i];
            	   else if(i==10){
            		   act1=new actorNode();
            		   act1.name=abc[i];
            	   }
            	   else if(i==11)
            		   movie_title=abc[i];
            	   else if(i==12)
            		   num_voted_users=Integer.valueOf(abc[i]);
            	   else if(i==13)
                  cast_total_fb_likes=Integer.valueOf(abc[i]);
            	   else if(i==14){
            		   act3=new actorNode();
            		   act3.name=abc[i];
            	   }
            	   else if(i==15)
            		   face_num_in_poster=Integer.valueOf(abc[i]);
            	   else if(i==16)
            		   movie_idmb_link=abc[i];
            	   else if(i==17)
            		   num_user_for_reviews=Integer.valueOf(abc[i]);
            	   else if(i==18)
            		   language=abc[i];
            	   else if(i==19)
            		   country=abc[i];
            	   else if(i==21)
            		   content_rating=abc[i];
            	   else if(i==22)
            		   budget=abc[i];
            	   else if(i==23)
            		   title_year=Integer.valueOf(abc[i]);
            	   else if(i==24)
            		   actor_2_fb_likes=Integer.valueOf(abc[i]);
            	   else if(i==25)
            		   idmb_score=Integer.valueOf(abc[i]);
            	   else if(i==26)
            		   aspect_ratio=Integer.valueOf(abc[i]);
            	   else if(i==27)
            		   movie_fb_likes=Integer.valueOf(abc[i]);
               }
               
            mov=new movieNode(color,direc,num_critic_for_reviews,
        duration,director_fb_likes,actor_3_fb_likes, act2,actor_1_fb_likes,gross
        ,act1,movie_title,num_voted_users,cast_total_fb_likes,act3,face_num_in_poster,
        movie_idmb_link,num_user_for_reviews,language,country,content_rating,budget,
        title_year,actor_2_fb_likes,idmb_score, aspect_ratio,movie_fb_likes);
avl.insert(mov);*/