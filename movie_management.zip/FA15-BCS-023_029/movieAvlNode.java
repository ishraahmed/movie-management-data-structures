
public class movieAvlNode {
movieNode data;
movieAvlNode left;
movieAvlNode right;
int height;
}
