

public class movies_linkedlist {
	movieNode head;
	movieNode loc;
	movieNode ploc;
	movies_linkedlist(){
		head=null;
		}
	public void add(movieNode mn){
		
	}
	/*public void add(movieNode mn){
		System.out.println("ka");
		if(head==null){
			head=mn;
		}
		else if(head!=null){
			System.out.println("head"+head);
			ploc=head;
			loc=head.next;
		while(loc!=null){
			ploc=loc;
			loc=loc.next;
		}
		}
		
		System.out.println(head+head.director_Name.name);
		head.next=mn;
	}*/

	public void addAtEnd(String col,directorNode d_n,int num_c_r,int dur,int direc_fb_likes,int act_3_fb_likes,actorNode actor2,
			int act1_fb_likes,String gros,actorNode actor1,String m_t,int n_v_u,int c_t_fb_likes,actorNode actor3,
			int f_n_i_p,String m_idmb_link,int n_u_for_reviews,String lang,String coun,String c_r,
			String bud,int t_y,int act2_fb_likes,Double i_s,Double a_r,int m_f_likes,genres_linkedlist gen,plot_keywords pl){
		movieNode nn=new movieNode(col,d_n,num_c_r,dur,direc_fb_likes,act_3_fb_likes,actor2,act1_fb_likes,gros,
				actor1,m_t, n_v_u,c_t_fb_likes,actor3,f_n_i_p,m_idmb_link,n_u_for_reviews,lang,coun,c_r,bud,t_y,
				act2_fb_likes,i_s,a_r,m_f_likes,gen,pl);
		//nn.movie=item;
		loc=head;
		while(loc.next!=null){
			loc=loc.next;
		}
		loc.next=nn;
		
	}
	public void addAtFront(String col,directorNode d_n,int num_c_r,int dur,int direc_fb_likes,int act_3_fb_likes,actorNode actor2,
			int act1_fb_likes,String gros,actorNode actor1,String m_t,int n_v_u,int c_t_fb_likes,actorNode actor3,
			int f_n_i_p,String m_idmb_link,int n_u_for_reviews,String lang,String coun,String c_r,
			String bud,int t_y,int act2_fb_likes,Double i_s,Double a_r,int m_f_likes,genres_linkedlist gen,plot_keywords pl){
		movieNode nn=new movieNode(col,d_n,num_c_r,dur,direc_fb_likes,act_3_fb_likes,actor2,act1_fb_likes,gros,
				actor1,m_t, n_v_u,c_t_fb_likes,actor3,f_n_i_p,m_idmb_link,n_u_for_reviews,lang,coun,c_r,bud,t_y,
				act2_fb_likes,i_s,a_r,m_f_likes,gen,pl);
		//nn.movie=item;
		nn.next=head;
		head=nn;
		//numItems++;
	}
	public void printList(){
		
		loc=head;
		while(loc!=null){
			System.out.println(loc.movie_title);
			loc=loc.next;
		}
		}
}


