

public class genres_linkedlist {
	genresNode head;
	genresNode loc;
	genres_linkedlist(){
		head=null;
		
	}
	public void addAtEnd(movies_linkedlist item,String word){
		genresNode nn=new 	genresNode();
		nn.m=item;
		nn.genre=word;
		loc=head;
		while(loc.next!=null){
			loc=loc.next;
		}
		loc.next=nn;
		
	}
	public void addAtFront(movies_linkedlist item,String word){
		genresNode nn=new 	genresNode();
		nn.m=item;
		nn.genre=word;
		nn.next=head;
		head=nn;
		//numItems++;
	}
	public void printList(){
		loc=head;
		while(loc!=null){
			System.out.println("genre="+loc.genre);
			loc=loc.next;
		}
		}
	public genresNode findKey(String item){
		loc=head;
		while(loc.next!=null){
			if(item!=null){
			if((loc.genre).compareTo(item)==0){
			break;
			}
			}
			loc=loc.next;
		}
		return loc;
		}
}
