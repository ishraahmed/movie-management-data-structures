
public class view_main {
public static void main(String args[])
{
	view v=new view();
	v.setVisible(true);
	}
}



