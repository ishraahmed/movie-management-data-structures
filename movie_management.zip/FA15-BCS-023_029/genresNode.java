
public class genresNode {
String genre;
movies_linkedlist m;
genresNode next;
}
