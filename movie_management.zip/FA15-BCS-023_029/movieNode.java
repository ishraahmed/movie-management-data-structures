public class movieNode {
String color;
directorNode director_Name;
int num_critic_for_reviews;
int duration;
int director_fb_likes;
int actor_3_fb_likes;
actorNode actor_2;
int actor_1_fb_likes;
String gross;
actorNode actor_1;
String movie_title;
int num_voted_users;
int cast_total_fb_likes;
actorNode actor_3;
int face_num_in_poster;
String movie_idmb_link;
int num_user_for_reviews;
String language;
String country;
String content_rating;
String budget;
int title_year;
int actor_2_fb_likes;
Double idmb_score;
Double aspect_ratio;
int movie_fb_likes;
genres_linkedlist genres;
plot_keywords plotAvl;
movieNode next;
movieNode(String col,directorNode d_n,int num_c_r,int dur,int direc_fb_likes,int act_3_fb_likes,actorNode actor2,
		int act1_fb_likes,String gros,actorNode actor1,String m_t,int n_v_u,int c_t_fb_likes,actorNode actor3,
		int f_n_i_p,String m_idmb_link,int n_u_for_reviews,String lang,String coun,String c_r,
		String bud,int t_y,int act2_fb_likes,Double i_s,Double a_r,int m_f_likes,genres_linkedlist g,plot_keywords pl) {
	genres=g;
	plotAvl=pl;
    color=col;
    director_Name=d_n;
    num_critic_for_reviews=num_c_r;
    duration=dur;
    director_fb_likes=direc_fb_likes;
    actor_3_fb_likes=act_3_fb_likes;
    actor_2=actor2;
    actor_1_fb_likes=act1_fb_likes;
    gross=gros;
    actor_1=actor1;
    movie_title=m_t;
    num_voted_users=n_v_u;
    cast_total_fb_likes=c_t_fb_likes;
    actor_3=actor3;
    face_num_in_poster=f_n_i_p;
    movie_idmb_link=m_idmb_link;
    num_user_for_reviews=n_u_for_reviews;
    language=lang;
    country=coun;
    content_rating=c_r;
    budget=bud;
    title_year=t_y;
    actor_2_fb_likes=act2_fb_likes;
    idmb_score=i_s;
    aspect_ratio=a_r;
    movie_fb_likes=m_f_likes;

}
}
