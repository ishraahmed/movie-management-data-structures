
public class actorMethods {
	public movieNode actorMoviesView(String actor){
		actorNode node=reading.ha.search(actor);
		movies_linkedlist m=node.list;
		movieNode mn=m.head;
return mn;
	
}
	public void actorMovies(String actor){
		actorNode node=reading.ha.search(actor);
		movies_linkedlist m=node.list;
		movieNode mn=m.head;
		while(mn!=null){
			System.out.println("Movie Title="+mn.movie_title);
			System.out.println("Title Year="+mn.title_year);
			System.out.println("Actor 1="+mn.actor_1.name);
			System.out.println("Actor 2="+mn.actor_2.name);
			System.out.println("Actor 3="+mn.actor_3.name);
			mn=mn.next;

		}
	
}
	public void coactors(String movie){
	hashmovie h=reading.h;
	movieAvlNode mv=h.search(movie);
	System.out.println(mv.data.actor_1.name+"     "+mv.data.actor_2.name+"      "+mv.data.actor_3.name);
	}


	public movieAvlNode coactorsView(String movie){
	hashmovie h=reading.h;
	movieAvlNode mv=h.search(movie);
//	System.out.println(mv.data.actor_1.name+"     "+mv.data.actor_2.name+"      "+mv.data.actor_3.name);
	return mv;
	}
public void  all_coactors(String actor_name){
	hashActor ha=reading.ha;
	actorNode an=ha.search(actor_name);
	movies_linkedlist m=an.list;
	movieNode loc=an.list.head;
		while(loc!=null){
			System.out.println(loc.actor_1.name+"   "+loc.actor_2.name+"    "+loc.actor_3.name);
			loc=loc.next;
		}
}
public movieNode  all_coactorsView (String actor_name){
	hashActor ha=reading.ha;
	actorNode an=ha.search(actor_name);
	movies_linkedlist m=an.list;
	movieNode loc=an.list.head;
		return loc;
}
}