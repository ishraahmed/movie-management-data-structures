public class actorAvlTree {
	 actorNode root;
	 
	   
	    int height(actorNode N) {
	        if (N == null)
	            return 0;
	 
	        return N.height;
	    }
	 
	
	    int max(int a, int b) {
	    	 if (a > b) 
	 	    	return a;
	 	    else return b;
	    }
public actorNode rightRotate(actorNode y) {
	actorNode x = y.left;
	//System.out.println(x.name);
	if(x!=null){
	actorNode T2 = x.right;
	 
	        x.right = y;
	        y.left = T2;
	 
	        y.height = max(height(y.left), height(y.right)) + 1;
	        x.height = max(height(x.left), height(x.right)) + 1;
	}
	        return x;
	    }
	 
	
actorNode leftRotate(actorNode x) {
	actorNode y = x.right;
	if(y!=null){
	actorNode T2 = y.left;
	 
	        y.left = x;
	        x.right = T2;
	 
	        x.height = max(height(x.left), height(x.right)) + 1;
	        y.height = max(height(y.left), height(y.right)) + 1;
	}

	        return y;
	    }
	 
	
	    int getBalance(actorNode N) {
	        if (N == null)
	            return 0;
	 
	        return height(N.left) - height(N.right);
	    }
	    public actorNode Node(movies_linkedlist m,String n){
	    	actorNode ac=new actorNode();
	    	ac.list=m;
	    	ac.name=n;
	    	ac.left=null;
	    	ac.right=null;
	    	ac.height=1;
	    	return ac;
	    }
	    public actorNode  insert(movies_linkedlist m,String n){
	    	return root=insert(root,m,n);
	    }
	    actorNode insert(actorNode node,movies_linkedlist m,String n) {
	    	 
	        
	        if (node == null)
	            return (Node(m,n));
	 
	        if (n.compareTo(node.name)<0)
	            node.left = insert(node.left,m,n);
	        else if (n.compareTo(node.name)>0)
	            node.right = insert(node.right,m,n);
	        else // Duplicate keys not allowed
	            return node;
	 
	        
	        node.height = 1 + max(height(node.left),
	                              height(node.right));
	 
	        int balance = getBalance(node);
	 
	        //left left rotation
	        if (balance > 1 && n.compareTo(node.left.name)<0)
	            return rightRotate(node);
	 
	        // Right Right Case
	        if (balance < -1 && n.compareTo(node.right.name)>0)
	            return leftRotate(node);
	 
	        // Left Right Case
	        if (balance > 1 &&n.compareTo(node.left.name)>0) {
	            node.left = leftRotate(node.left);
	            return rightRotate(node);
	        }
	 
	        // Right Left Case
	        if (balance < -1 && n.compareTo(node.right.name)<0) {
	            node.right = rightRotate(node.right);
	            return leftRotate(node);
	        }
	 
	        return node;
	    }
	    public void traverse(){
	    	traverse(root);
	    }
	    public void traverse(actorNode node) {
	        if (node != null) {
	            System.out.println(node.name + " ");
	            traverse(node.left);
	            traverse(node.right);
	        }
	    }
	    public actorNode search(String val){
	    	actorNode temp=root;
	    	String rval=temp.name;
	    	boolean found=false;
	    	while(temp!=null&&!found){
	    		rval=temp.name;
	    		if(val.compareTo(rval)<0){
	    			temp=temp.left;

	    		}
	    		else if(val.compareTo(rval)>0){
	    			temp=temp.right;
	    		}
	    		else
	    			found=true;
	    	}
	    	if(found==false)
	    		return null;
	    	else return temp;
	    }
}
