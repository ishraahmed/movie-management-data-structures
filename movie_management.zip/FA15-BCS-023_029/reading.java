import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
public final class reading {
	final static genres_linkedlist gl= new  genres_linkedlist();
	final static hashmovie h=new hashmovie();
	final static hashActor ha=new hashActor();
	final static hashdirector hd=new hashdirector();
	final static plot_keywords pl=new plot_keywords();
static List<movieNode> movieList = null;
static List<String> actors = null;
static List<String> directors = null;
static List<String> gen = null;
static List<String> plot_keywords = null;
reading(){
	movies(); //arraylist of movienodes (5044)
	actorlist(); //arraylist of all actors
	actors(); //inserting actor nodes int0 hashactor
	savemovie(); // insert 5044 nodes into hashmovie
	gen(); //arraylist of genres
	directorList(); //arraylist of directors
	directorsRecord(); //inserting director nodes into hashdirector/
	savedir(); //insert hashdirector references into hashmovie
	saveactors(); //insert hashactor references into hashmovie
	gendata(); //makes linkedlist of genres
	savegenres(); //insert genres_linkedlist references into hashmovie
	plotkeywords(); //arraylist
	movieList=null;
	actors=null;
	directors=null;
	gen=null;
	}
public static void movies(){
		 String COMMA_DELIMITER = ",";
	  
	        BufferedReader br = null;
	        try
	        {
	            //Reading the csv file
	            br = new BufferedReader(new FileReader("C:\\Users\\Ishra Ahmed\\idmb.csv"));
	            
	            //Create List for holding Employee objects
	             movieList = new ArrayList<movieNode>();
	            
	            String line = "";
	            //Read to skip the header
	            br.readLine();
	            //Reading from the second line
	            while ((line = br.readLine()) != null) 
	            {
	                String[] abc = line.split(COMMA_DELIMITER);
	                
	                if(abc.length > 0 )
	                {
	              
	                if(abc[24].equals("")||abc[3].equals("")||abc[25].equals("")||abc[2].equals("")||
	             		   abc[7].equals("")||abc[19].equals("")||abc[18].equals("")||abc[4].equals("")||
	             		   abc[15].equals("")||abc[5].equals("")||abc[3].equals("")||abc[18].equals("")||
	             		   abc[23].equals("")||abc[26].equals("")){
	             
	             	   if(abc[2].equals(""))
	             	   abc[2]="0";
	             	  if(abc[3].equals(""))
	                	   abc[3]="0";
	             	  if(abc[7].equals(""))
	                	   abc[7]="0";
	             	   if(abc[26].equals(""))
	                 	   abc[26]="0";
	             	   if(abc[19].equals(""))
	             	   abc[19]="0";
	             	   if(abc[24].equals(""))
	                 	   abc[24]="0";
	                 	   if(abc[25].equals(""))
	                 	   abc[25]="0";
	             	   if(abc[18].equals(""))
	                 	   abc[18]="0";
	             	   if(abc[4].equals(""))
	                 	   abc[4]="0";
	             	   if(abc[15].equals(""))
	                 	   abc[15]="0";
	             	   if(abc[3].equals(""))
	                 	   abc[3]="0";
	             	   if(abc[18].equals(""))
	                 	   abc[18]="0";
	             	   if(abc[23].equals(""))
	                 	   abc[23]="0";
	             	   if(abc[5].equals(""))
	                 	   abc[5]="0";
	                if(abc[26].equals(""))
	             	   abc[26]="0.0";
	                }
	                directorNode director_Name=new directorNode();
	                director_Name.name=abc[1];
	               	actorNode actor_2=new actorNode();
	          		   actor_2.name=abc[6];
	          		 actorNode actor_1=new actorNode();
	        		   actor_1.name=abc[10];
	        		   actorNode actor_3=new actorNode();
	   		   actor_3.name=abc[14];
	   		 String mt="";
	   		 for(int i=0;i<abc[11].length();i++){
	   			char ch=abc[11].charAt(i);
	   			if(ch!='�'){
	   				mt=mt+ch;
	   			}
	   			if(ch=='�'){
	   				break;
	   			}
	   		 }
	   		genres_linkedlist glll = new genres_linkedlist();
	   		 glll.addAtFront(null,abc[9]);
	   		plot_keywords pl=new plot_keywords();
	   		pl.insert(null,abc[16]);
	   		//System.out.println("root"+pl.root);
	                 	movieNode mov=new movieNode(abc[0],director_Name,Integer.valueOf(abc[2]),Integer.valueOf(abc[3]),Integer.valueOf(abc[4]),Integer.valueOf(abc[5]),
	                 			actor_2,Integer.valueOf(abc[7]),abc[8],actor_1,mt,Integer.valueOf(abc[12]),Integer.valueOf(abc[13]),actor_3,Integer.valueOf(abc[15]),
	                 			abc[17],Integer.valueOf(abc[18]),abc[19],abc[20],abc[21],abc[22],Integer.valueOf(abc[23]),Integer.valueOf(abc[24]),Double.valueOf(abc[25]),
	                 			Double.valueOf(abc[26]),Integer.valueOf(abc[27]),glll,pl);
	                 	//System.out.println(abc[27]);
	                    movieList.add(mov);
	                }
	            }
	     
	          
	        }
	        catch(Exception ee)
	        {
	            ee.printStackTrace();
	        }
	        finally
	        {
	            try
	            {
	                br.close();
	            }
	            catch(IOException ie)
	            {
	                System.out.println("Error occured while closing the BufferedReader");
	                ie.printStackTrace();
	            }
	        }
}
public static void actorlist(){
	actors=new ArrayList<String>();
	for(int i=0;i<movieList.size();i++){
		String name=movieList.get(i).actor_1.name;
		if(actors.contains(name));
		else{
			actors.add(name);
		}
		name=movieList.get(i).actor_2.name;
		if(actors.contains(name));
		else{
			actors.add(name);
		}
		name=movieList.get(i).actor_3.name;
		if(actors.contains(name));
		else{
			actors.add(name);
		}
	}
}
public static void actors(){
	for(int i=0;i<actors.size();i++){
		movies_linkedlist m=new movies_linkedlist();
		String name=actors.get(i);
		for(int j=0;j<movieList.size();j++){
			if(name.equals(movieList.get(j).actor_1.name)||name.equals(movieList.get(j).actor_2.name)||
					name.equals(movieList.get(j).actor_3.name)){
				movieNode mk=movieList.get(j);
				 m.addAtFront(mk.color,mk.director_Name,mk.num_critic_for_reviews,mk.duration,mk.director_fb_likes,
      				   mk.actor_3_fb_likes,mk.actor_2,mk.actor_1_fb_likes,mk.gross,mk.actor_1,mk.movie_title,mk.num_voted_users,
      				   mk.cast_total_fb_likes,mk.actor_3,mk.face_num_in_poster,mk.movie_idmb_link,mk.num_user_for_reviews,
      				   mk.language,mk.country,mk.content_rating,mk.budget,mk.title_year,mk.actor_2_fb_likes,mk.idmb_score,
      				   mk.aspect_ratio,mk.movie_fb_likes,mk.genres,mk.plotAvl);
				 
				
			}
		}
		ha.insert(m, name);
	}
}
public static void savemovie(){
	for(int i=0;i<movieList.size();i++){
		h.insert(movieList.get(i));
	}
}
public void gendata(){
	for(int i=0;i<gen.size();i++){
		String genre=gen.get(i);
		movies_linkedlist m=new movies_linkedlist();
		for(int j=0;j<movieList.size();j++){
			String[] arr=new String[12];
			int ind=0;
			String st="";
			String g=movieList.get(j).genres.head.genre;
		for(int k=0;k<g.length();k++){
			char ch=g.charAt(k);
			if(ch!='|'){
				st=st+ch;
			}
			else{
				arr[ind]=st;
				st="";
				ind++;
			}
		}
		arr[ind]=st;
		for(int l=0;l<arr.length;l++){
			if(arr[l]!=null&&arr[l]!=""){
				if(genre.equals(arr[l])){
					m.addAtFront(movieList.get(j).color,movieList.get(j).director_Name,
movieList.get(j).num_critic_for_reviews,movieList.get(j).duration,movieList.get(j).director_fb_likes,
movieList.get(j).actor_3_fb_likes, movieList.get(j).actor_2,movieList.get(j).actor_1_fb_likes,
movieList.get(j).gross,movieList.get(j).actor_1,movieList.get(j).movie_title,movieList.get(j).num_voted_users,
movieList.get(j).cast_total_fb_likes,movieList.get(j).actor_3,movieList.get(j).face_num_in_poster,
movieList.get(j).movie_idmb_link,movieList.get(j).num_user_for_reviews,movieList.get(j).language,movieList.get(j).country
,movieList.get(j).content_rating,movieList.get(j).budget,movieList.get(j).title_year,movieList.get(j).actor_2_fb_likes,
movieList.get(j).idmb_score, movieList.get(j).aspect_ratio,movieList.get(j).movie_fb_likes ,movieList.get(j).genres ,movieList.get(j).plotAvl);
									}
			}
		}
		}
		gl.addAtFront(m,genre);
	}
}
public void keywordsdata(){
	for(int i=0;i<plot_keywords.size();i++){
		System.out.println(plot_keywords.get(i));
		String key=plot_keywords.get(i);
		movies_linkedlist m=new movies_linkedlist();
		for(int j=0;j<movieList.size();j++){
			String[] arr=new String[12];
			int ind=0;
			String st="";
			String g=movieList.get(j).plotAvl.root.word;
		for(int k=0;k<g.length();k++){
			char ch=g.charAt(k);
			if(ch!='|'){
				st=st+ch;
			}
			else{
				arr[ind]=st;
				st="";
				ind++;
			}
		}
		arr[ind]=st;
		for(int l=0;l<arr.length;l++){
			if(arr[l]!=null&&arr[l]!=""){
				if(key.equals(arr[l])){
					m.addAtFront(movieList.get(j).color,movieList.get(j).director_Name,
movieList.get(j).num_critic_for_reviews,movieList.get(j).duration,movieList.get(j).director_fb_likes,
movieList.get(j).actor_3_fb_likes, movieList.get(j).actor_2,movieList.get(j).actor_1_fb_likes,
movieList.get(j).gross,movieList.get(j).actor_1,movieList.get(j).movie_title,movieList.get(j).num_voted_users,
movieList.get(j).cast_total_fb_likes,movieList.get(j).actor_3,movieList.get(j).face_num_in_poster,
movieList.get(j).movie_idmb_link,movieList.get(j).num_user_for_reviews,movieList.get(j).language,movieList.get(j).country
,movieList.get(j).content_rating,movieList.get(j).budget,movieList.get(j).title_year,movieList.get(j).actor_2_fb_likes,
movieList.get(j).idmb_score, movieList.get(j).aspect_ratio,movieList.get(j).movie_fb_likes ,movieList.get(j).genres ,movieList.get(j).plotAvl);
									}
			}
		}
		}
		if(m.head!=null)
		System.out.println(m.head.movie_title);
	pl.insert(m,key);
	}
}
public void savekeywords(){
	for(int i=0;i<movieList.size();i++){
		plot_keywords pkey=new plot_keywords();
		String movie=movieList.get(i).movie_title;
		movieAvlNode mav=h.search(movie);
		if(mav.data.plotAvl.root!=null){
		String key=mav.data.plotAvl.root.word;
		String st="";
		int ind=0;
		String[] arr=new String[12];
		for(int j=0;j<key.length();j++){
			char ch=key.charAt(j);
			if(ch!='|'){
				st=st+ch;
			}
			else{
				arr[ind]=st;
				st="";
				ind++;
			}
		}
		arr[ind]=st;
		for(int k=0;k<arr.length;k++){
			if(arr[k]!=null&&arr[k]!=""){
				String g=arr[k];
				plotNode gn=pl.search(g);
			//	System.out.println(gn.m);
				pkey.insert(gn.m,g);
			}
		}
//		System.out.println(pkey.root);
		mav.data.plotAvl=pkey;
	}
}}
public static List<String> plotkeywords(){
	plot_keywords=new ArrayList<String>();
	for(int i=0;i<movieList.size();i++){
		//System.out.println(movieList.get(i).plotAvl.root);
		if(movieList.get(i).plotAvl.root!=null){
		String word=movieList.get(i).plotAvl.root.word;
		String st="";
        for(int j=0;j<word.length();j++){
      	  char ch=word.charAt(j);
      	  if(ch!='|'){
      		  st=st+ch;
      	  }
      	  else if(ch=='|'){
      		  if(plot_keywords.contains(st)==true);
      		  else plot_keywords.add(st);
      		  st="";
      	  }
	}
        if(plot_keywords.contains(st)==false)
        	plot_keywords.add(st);
	}}
	return plot_keywords;
}
public void savegenres(){
	for(int i=0;i<movieList.size();i++){
		genres_linkedlist glist=new genres_linkedlist();
		String movie=movieList.get(i).movie_title;
		movieAvlNode mav=h.search(movie);
		String genre=mav.data.genres.head.genre;
		String st="";
		int ind=0;
		String[] arr=new String[12];
		for(int j=0;j<genre.length();j++){
			char ch=genre.charAt(j);
			if(ch!='|'){
				st=st+ch;
			}
			else{
				arr[ind]=st;
				st="";
				ind++;
			}
		}
		arr[ind]=st;
		for(int k=0;k<arr.length;k++){
			if(arr[k]!=null&&arr[k]!=""){
				String g=arr[k];
				genresNode gn=gl.findKey(g);
			//	System.out.println(gn.m);
				glist.addAtFront(gn.m,g);
			}
		}
		mav.data.genres=glist;
	}
}
public static List<String> gen(){
	gen=new ArrayList<String>();
	for(int i=0;i<movieList.size();i++){
		String genre=movieList.get(i).genres.head.genre;
		String st="";
        for(int j=0;j<genre.length();j++){
      	  char ch=genre.charAt(j);
      	  if(ch!='|'){
      		  st=st+ch;
      	  }
      	  else if(ch=='|'){
      		  if(gen.contains(st)==true);
      		  else gen.add(st);
      		  st="";
      	  }
	}
        if(gen.contains(st)==false)
        gen.add(st);
	}
	return gen;
}

public void directorList(){
	directors=new ArrayList<String>();
	for(int i=0;i<movieList.size();i++){
		String d_n=movieList.get(i).director_Name.name;
		if(directors.contains(d_n)==false)
			directors.add(d_n);
	}
}
public void directorsRecord(){
	for(int i=0;i<directors.size();i++){
		movies_linkedlist m=new movies_linkedlist();
		String d_n=directors.get(i);
		for(int j=0;j<movieList.size();j++){
			if(d_n.equals(movieList.get(j).director_Name.name)){
				movieNode mk=movieList.get(j);
				 m.addAtFront(mk.color,mk.director_Name,mk.num_critic_for_reviews,mk.duration,mk.director_fb_likes,
     				   mk.actor_3_fb_likes,mk.actor_2,mk.actor_1_fb_likes,mk.gross,mk.actor_1,mk.movie_title,mk.num_voted_users,
     				   mk.cast_total_fb_likes,mk.actor_3,mk.face_num_in_poster,mk.movie_idmb_link,mk.num_user_for_reviews,
     				   mk.language,mk.country,mk.content_rating,mk.budget,mk.title_year,mk.actor_2_fb_likes,mk.idmb_score,
     				   mk.aspect_ratio,mk.movie_fb_likes,mk.genres,mk.plotAvl);
			}
		}
		hd.insert(m,d_n);
	//	if(m.head!=null)
//		System.out.println(m.head.director_Name.name);
	}
}
public void savedir(){
	for(int i=0;i<directors.size();i++){
		String name=directors.get(i);
				directorNode dn=hd.search(name);
				movies_linkedlist m=dn.list;
				movieNode mn =m.head;
				movieNode loc=mn;
				while(loc!=null){
					String movie=loc.movie_title;
					movieAvlNode mv=h.search(movie);
					mv.data.director_Name=dn;
					loc=loc.next;
				}
	}
	}

public void saveactors(){
	for(int i=0;i<actors.size();i++){
		String name=actors.get(i);
	actorNode anode=ha.search(name);
	movies_linkedlist m;
	movieNode mn = null;
	if(anode!=null){
	m=anode.list;
	mn=m.head;}
	movieNode loc=mn;
	while(loc!=null){
		String movie=loc.movie_title;
		movieAvlNode mv=h.search(movie);
		if(mv.data.actor_1.name.equals(name))
			mv.data.actor_1=anode;
		if(mv.data.actor_2.name.equals(name))
			mv.data.actor_2=anode;
		if(mv.data.actor_3.name.equals(name))
			mv.data.actor_3=anode;
		loc=loc.next;
	}
	}
}
}

