import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;


public class view extends JFrame{
	JTextArea t=new JTextArea();
	JLabel l[];
	JTextField[] f; 
	JButton[] b;
	JLabel ll;
	JLabel ll1;
	JButton bu;
	view(){
		super("Search");
		setContentPane(new JLabel(new ImageIcon("2.jpg")));
		this.setLayout(new BorderLayout());
	JPanel p=new JPanel(new GridLayout(9,2));
	JPanel p1=new JPanel();
	bu=new JButton("Insert");
	p.setOpaque(false);
	p1.setOpaque(false);
	JPanel[] p2=new JPanel[32];
	for(int i=0;i<32;i++){
		p2[i]=new JPanel();
	}
	for(int i=0;i<32;i++){
		p2[i].setOpaque(false);;
	}
	ll=new JLabel("                     ");
	ll1=new JLabel("      ");
	l=new JLabel[9];
	f=new JTextField[8];
	b=new JButton[8];
	l[0]=new JLabel("      Genre");
	l[0].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[0].setBackground(Color.MAGENTA);
	//l[0].setOpaque(true);
	l[0].setForeground(Color.lightGray);
	l[1]=new JLabel("        Movie Title");
	l[1].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[2]=new JLabel("      Actor");
	l[2].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[3]=new JLabel("        Rating Range");
	l[3].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[4]=new JLabel("      Title Year");
	l[4].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[5]=new JLabel("        Director");
	
	l[5].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[5].setBackground(Color.LIGHT_GRAY);
	l[6]=new JLabel("      Co-Actors of Movie");
	l[6].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[6].setBackground(Color.LIGHT_GRAY);
	l[7]=new JLabel("        Co-Actors of Actor");
	l[7].setFont(new Font("ALGERIAN",Font.PLAIN,15));
	l[8]=new JLabel("search window");
	l[8].setFont(new Font("ALGERIAN",Font.BOLD,35));
	l[7].setForeground(Color.lightGray);
	l[2].setForeground(Color.lightGray);
	l[3].setForeground(Color.lightGray);
	l[4].setForeground(Color.lightGray);
	l[5].setForeground(Color.lightGray);
	l[6].setForeground(Color.lightGray);
	l[1].setForeground(Color.lightGray);
	l[8].setForeground(Color.lightGray);
	for(int i=0;i<8;i++){
	f[i]=new JTextField(10);}
	for(int i=0;i<8;i++){
		b[i]=new JButton("Search");}
	b[0].setSize(10,10);
	p.add(p2[0]);
	p.add(p2[1]);
	p.add(p2[2]);
	p.add(p2[3]);
	p.add(p2[4]);
	p.add(p2[5]);
	p.add(l[0]);
	p.add(f[0]);
	p.add(b[0]);
	p.add(l[1]);
	p.add(f[1]);
	p.add(b[1]);
	p.add(p2[6]);
	p.add(p2[7]);
	p.add(p2[8]);
	p.add(p2[9]);
	p.add(p2[10]);
	p.add(p2[11]);
	p.add(l[2]);
	p.add(f[2]);
	p.add(b[2]);
	p.add(l[3]);
	p.add(f[3]);
	p.add(b[3]);
	p.add(p2[12]);
	p.add(p2[13]);
	p.add(p2[14]);
	p.add(p2[15]);
	p.add(p2[16]);
	p.add(p2[17]);
	p.add(l[4]);
	p.add(f[4]);
	p.add(b[4]);
	p.add(l[5]);
	p.add(f[5]);
	p.add(b[5]);
	p.add(p2[18]);
	p.add(p2[19]);
	p.add(p2[20]);
	p.add(p2[21]);
	p.add(p2[22]);
	p.add(p2[23]);
	p.add(l[6]);
	p.add(f[6]);
	p.add(b[6]);
	p.add(l[7]);
	p.add(f[7]);
	p.add(b[7]);
	p.add(p2[24]);
	p.add(p2[25]);
	p.add(p2[26]);
	p.add(p2[27]);
	p.add(p2[28]);
	p.add(p2[29]);
	p1.add(bu);
	p1.add(l[8]);
	this.add(p,BorderLayout.CENTER);
	this.add(p1,BorderLayout.NORTH);
	p2[30].add(ll);
	p2[31].add(ll1);
	this.add(p2[30],BorderLayout.EAST);
	this.add(p2[31],BorderLayout.WEST);
	this.setSize(1350,720);
	this.setVisible(true);
	MyButton butt=new MyButton();
	b[0].addActionListener(butt);
	b[1].addActionListener(butt);
	b[2].addActionListener(butt);
	b[3].addActionListener(butt);
	b[4].addActionListener(butt);
	b[5].addActionListener(butt);
	b[6].addActionListener(butt);
	b[7].addActionListener(butt);
	bu.addActionListener(butt);
		}
	class MyButton implements ActionListener{
		
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==bu){
				movieMethod m=new movieMethod();
				m.inserdata();
			}
			if(e.getSource()==b[4]){
				int year=Integer.parseInt(f[4].getText());
				movieMethod m=new movieMethod();
				List<movieNode> mn=m.searchyearView(year);
				 File newTextFile=new File("new.txt");
				 int a=1;
					try {
						FileWriter fw=new FileWriter(newTextFile);
						for(int i=0;i<mn.size();i++){
							fw.write(String.valueOf(a));
							fw.write(" : ");
								fw.write(mn.get(i).movie_title);
								fw.write('\n');
								a++;
						}		
						
						fw.close();
			          JFrame f=new JFrame();
			          f.setLayout(new BorderLayout());
			          JTextArea fe=new JTextArea();
			          fe.setLineWrap(true);
			          fe.setWrapStyleWord(true);
			          JScrollPane sp=new JScrollPane(fe);
			          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			          f.add(sp,BorderLayout.CENTER);
			        
			        FileReader reader=new FileReader("new.txt");
			        BufferedReader br=new BufferedReader(reader);
			        fe.read(br,null);
			         br.close();
			         fe.requestFocus();
			         f.setVisible(true);
			         f.setSize(500,500);
			         
					}catch(Exception exp){
						return;
					}
				 
			}
			if(e.getSource()==b[3]){
				System.out.println(f[3].getText());
				String st=f[3].getText();
				String str="";
				String min1 = "",max1 = "";
				Double min = 0.0,max=0.0;
				for(int i=0;i<st.length();i++){
					System.out.println("ye");
				char ch=st.charAt(i);
				System.out.println(ch);
				
					str=str+ch;
						
							if(i>3){
							max1=str;
							System.out.println(max1);
							max=Double.parseDouble(max1);
							}
						else if(i==3){
							str="";
							}
						else{
							min1=str;
							System.out.println("mininum"+min1);
							min=Double.parseDouble(min1);
						}
				}
				movieMethod m=new movieMethod();
				List<movieNode> mn=m.searchRatingView(min,max);
				 File newTextFile=new File("new.txt");
					try {
						FileWriter fw=new FileWriter(newTextFile);
						int a = 1;
						for(int i=0;i<mn.size();i++){
							fw.write(String.valueOf(a));
							fw.write(" : ");
								fw.write(mn.get(i).movie_title);
								fw.write('\n');
								a++;
						}		
						
						fw.close();
			          JFrame f=new JFrame();
			          f.setLayout(new BorderLayout());
			          JTextArea fe=new JTextArea();
			          fe.setLineWrap(true);
			          fe.setWrapStyleWord(true);
			          JScrollPane sp=new JScrollPane(fe);
			          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
			          f.add(sp,BorderLayout.CENTER);
			        
			        FileReader reader=new FileReader("new.txt");
			        BufferedReader br=new BufferedReader(reader);
			        fe.read(br,null);
			         br.close();
			         fe.requestFocus();
			         f.setVisible(true);
			         f.setSize(500,500);
			         
					}catch(Exception exp){
						return;
					}
				 
			
			}
			if(e.getSource()==b[2]){
				String movie=f[2].getText();
				actorMethods ac=new actorMethods();
				movieNode n=ac.actorMoviesView(movie);
				File newTextFile=new File("new.txt");
				int a=1;
				try {
					FileWriter fw=new FileWriter(newTextFile);
					while(n!=null){
						fw.write(String.valueOf(a));
						fw.write(" : ");
							fw.write("Color : ");
							fw.write(n.color);
							fw.write('\n');
							fw.write("Director Name : ");
							fw.write(n.director_Name.name);
							fw.write('\n');
							fw.write("Number Critic For Reviews : ");
							int g=n.num_critic_for_reviews;
							String nk=String.valueOf(g);
							fw.write(nk);
							fw.write('\n');
							fw.write("Duration : ");
							int g1=n.duration;
							String nk1=String.valueOf(g1);
							fw.write(nk1);
							fw.write('\n');
							fw.write("Director Facebook Likes : ");
							int g2=n.director_fb_likes;
							String nk2=String.valueOf(g2);
							fw.write(nk2);
							fw.write('\n');
							fw.write("Actor no 1 : ");
							fw.write(n.actor_1.name);
							fw.write('\n');
							fw.write("Actor 1 FaceBook Likes : ");
							int g3=n.actor_1_fb_likes;
							String nk3=String.valueOf(g3);
							fw.write(nk3);
							fw.write('\n');
							fw.write("Actor no 2 : ");
							fw.write(n.actor_2.name);
							fw.write('\n');
							fw.write("Actor 2 Facebbok Likes : ");
							int g4=n.actor_2_fb_likes;
							String nk4=String.valueOf(g4);
							fw.write(nk4);
							fw.write('\n');
							fw.write("Actor no 3 : ");
							fw.write(n.actor_3.name);
							fw.write('\n');
							fw.write("Actor 3 Facebook Likes : ");
							int g5=n.actor_3_fb_likes;
							String nk5=String.valueOf(g5);
							fw.write(nk5);
							fw.write('\n');
							fw.write("Gross : ");
							fw.write(n.gross);
							fw.write('\n');
							fw.write("Genres : ");
							genresNode gn=n.genres.head;
							while(gn!=null){
							fw.write(gn.genre);
							fw.write("    ");
							gn=gn.next;}
							fw.write('\n');
							fw.write("Movie Title : ");
							fw.write(n.movie_title);
							fw.write('\n');
							fw.write("Number Voted Users : ");
							int g6=n.num_voted_users;
							String nk6=String.valueOf(g6);
							fw.write(nk6);
							fw.write('\n');
							fw.write("Cast Total Facebook Likes : ");
							int g7=n.cast_total_fb_likes;
							String nk7=String.valueOf(g7);
							fw.write(nk7);
							fw.write('\n');
							fw.write("Face Number in Poster : ");
							int g8=n.face_num_in_poster;
							String nk8=String.valueOf(g8);
							fw.write(nk8);
							fw.write('\n');
							fw.write("Plot Kewords : ");
							fw.write(n.plotAvl.root.word);
							fw.write('\n');
							fw.write("Number Voted Users : ");
							int g9=n.num_voted_users;
							String nk9=String.valueOf(g9);
							fw.write(nk9);
							fw.write('\n');
							fw.write("Movie IMDB Link : ");
							fw.write(n.movie_idmb_link);
							fw.write('\n');
							fw.write("Number User For Reviews : ");
							int g10=n.num_user_for_reviews;
							String nk10=String.valueOf(g10);
							fw.write(nk10);
							fw.write('\n');
							fw.write("Language : ");
							fw.write(n.language);
							fw.write('\n');
							fw.write("Country : ");
							fw.write(n.country);
							fw.write('\n');
							fw.write("Content Rating : ");
							fw.write(n.content_rating);
							fw.write('\n');
							fw.write("Budget : ");
							fw.write(n.budget);
							fw.write('\n');
							fw.write("Title Year : ");
							int g11=n.title_year;
							String nk11=String.valueOf(g11);
							fw.write(nk11);
							fw.write('\n');
							fw.write("IMDB Score : ");
							double d=n.idmb_score;
							String nn=String.valueOf(d);
							fw.write(nn);
							fw.write('\n');
							fw.write("Aspect Ratio : ");
							double d1=n.aspect_ratio;
							String nn1=String.valueOf(d1);
							fw.write(nn1);
							fw.write('\n');
							fw.write(".....................................End..................................");
							fw.write('\n');
							n=n.next;
							a++;
					}		
					
					//   f[1].setText(null);
					fw.close();
		          JFrame f=new JFrame();
		          f.setLayout(new BorderLayout());
		          JTextArea fe=new JTextArea();
		          fe.setLineWrap(true);
		          fe.setWrapStyleWord(true);
		          JScrollPane sp=new JScrollPane(fe);
		          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		          f.add(sp,BorderLayout.CENTER);
		        
		        FileReader reader=new FileReader("new.txt");
		        BufferedReader br=new BufferedReader(reader);
		        fe.read(br,null);
		         br.close();
		         fe.requestFocus();
		         f.setVisible(true);
		         f.setSize(500,500);
		         
				}catch(Exception exp){
					return;
				}
			}
		else if(e.getSource()==b[1]){
				String movie=f[1].getText();
				movieMethod m=new movieMethod();
				hashmovie h=reading.h;
				movieAvlNode mvl=h.search(movie);
				movieNode n=mvl.data;
				File newTextFile=new File("new.txt");
			//	int a=1;
				try {
					FileWriter fw=new FileWriter(newTextFile);
				//	fw.write(String.valueOf(a));
					//fw.write(" : ");
							fw.write("Color : ");
							fw.write(n.color);
							fw.write('\n');
							fw.write("Director Name : ");
							fw.write(n.director_Name.name);
							fw.write('\n');
							fw.write("Number Critic For Reviews : ");
							int g=n.num_critic_for_reviews;
							String nk=String.valueOf(g);
							fw.write(nk);
							fw.write('\n');
							fw.write("Duration : ");
							int g1=n.duration;
							String nk1=String.valueOf(g1);
							fw.write(nk1);
							fw.write('\n');
							fw.write("Director Facebook Likes : ");
							int g2=n.director_fb_likes;
							String nk2=String.valueOf(g2);
							fw.write(nk2);
							fw.write('\n');
							fw.write("Actor no 1 : ");
							fw.write(n.actor_1.name);
							fw.write('\n');
							fw.write("Actor 1 FaceBook Likes : ");
							int g3=n.actor_1_fb_likes;
							String nk3=String.valueOf(g3);
							fw.write(nk3);
							fw.write('\n');
							fw.write("Actor no 2 : ");
							fw.write(n.actor_2.name);
							fw.write('\n');
							fw.write("Actor 2 Facebook Likes : ");
							int g4=n.actor_2_fb_likes;
							String nk4=String.valueOf(g4);
							fw.write(nk4);
							fw.write('\n');
							fw.write("Actor no 3 : ");
							fw.write(n.actor_3.name);
							fw.write('\n');
							fw.write("Actor 3 Facebook Likes : ");
							int g5=n.actor_3_fb_likes;
							String nk5=String.valueOf(g5);
							fw.write(nk5);
							fw.write('\n');
							fw.write("Gross : ");
							fw.write(n.gross);
							fw.write('\n');
							fw.write("Genres : ");
							genresNode gn=n.genres.head;
							while(gn!=null){
							fw.write(gn.genre);
							fw.write("    ");
							gn=gn.next;}
							fw.write('\n');
							fw.write("Movie Title : ");
							fw.write(n.movie_title);
							fw.write('\n');
							fw.write("Number Voted Users : ");
							int g6=n.num_voted_users;
							String nk6=String.valueOf(g6);
							fw.write(nk6);
							fw.write('\n');
							fw.write("Cast Total Facebook Likes : ");
							int g7=n.cast_total_fb_likes;
							String nk7=String.valueOf(g7);
							fw.write(nk7);
							fw.write('\n');
							fw.write("Face Number in Poster : ");
							int g8=n.face_num_in_poster;
							String nk8=String.valueOf(g8);
							fw.write(nk8);
							fw.write('\n');
							fw.write("Plot Kewords : ");
							fw.write(n.plotAvl.root.word);
							fw.write('\n');
							fw.write("Number Voted Users : ");
							int g9=n.num_voted_users;
							String nk9=String.valueOf(g9);
							fw.write(nk9);
							fw.write('\n');
							fw.write("Movie IMDB Link : ");
							fw.write(n.movie_idmb_link);
							fw.write('\n');
							fw.write("Number User For Reviews : ");
							int g10=n.num_user_for_reviews;
							String nk10=String.valueOf(g10);
							fw.write(nk10);
							fw.write('\n');
							fw.write("Language : ");
							fw.write(n.language);
							fw.write('\n');
							fw.write("Country : ");
							fw.write(n.country);
							fw.write('\n');
							fw.write("Content Rating : ");
							fw.write(n.content_rating);
							fw.write('\n');
							fw.write("Budget : ");
							fw.write(n.budget);
							fw.write('\n');
							fw.write("Title Year : ");
							int g11=n.title_year;
							String nk11=String.valueOf(g11);
							fw.write(nk11);
							fw.write('\n');
							fw.write("IMDB Score : ");
							double d=n.idmb_score;
							String nn=String.valueOf(d);
							fw.write(nn);
							fw.write('\n');
							fw.write("Aspect Ratio : ");
							double d1=n.aspect_ratio;
							String nn1=String.valueOf(d1);
							fw.write(nn1);
							fw.write('\n');
							fw.write(".....................................End..................................");
							fw.write('\n');
					//a++;
					fw.close();
		          JFrame f=new JFrame();
		          f.setLayout(new BorderLayout());
		          JTextArea fe=new JTextArea();
		          fe.setLineWrap(true);
		          fe.setWrapStyleWord(true);
		          JScrollPane sp=new JScrollPane(fe);
		          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		          f.add(sp,BorderLayout.CENTER);
		        
		        FileReader reader=new FileReader("new.txt");
		        BufferedReader br=new BufferedReader(reader);
		        fe.read(br,null);
		         br.close();
		         fe.requestFocus();
		         f.setVisible(true);
		         f.setSize(500,500);
		         
				}catch(Exception exp){
					return;
				}
			}
		else if(e.getSource()==b[6]){
			String movie=f[6].getText();
			actorMethods m=new actorMethods();
			movieNode n= m.coactorsView(movie).data;
			File newTextFile=new File("new.txt");
			//int a=1;
			try {
				FileWriter fw=new FileWriter(newTextFile);
				//fw.write(String.valueOf(a));
				//fw.write(" : ");

						fw.write(n.actor_1.name);
						fw.write('\n');
						fw.write(n.actor_2.name);
						fw.write('\n');
						fw.write(n.actor_3.name);
						fw.write('\n');
					
				
				//a++;
				fw.close();
	          JFrame f=new JFrame();
	          f.setLayout(new BorderLayout());
	          JTextArea fe=new JTextArea();
	          fe.setLineWrap(true);
	          fe.setWrapStyleWord(true);
	          JScrollPane sp=new JScrollPane(fe);
	          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	          f.add(sp,BorderLayout.CENTER);
	        
	        FileReader reader=new FileReader("new.txt");
	        BufferedReader br=new BufferedReader(reader);
	        fe.read(br,null);
	         br.close();
	         fe.requestFocus();
	         f.setVisible(true);
	         f.setSize(500,500);
	         
			}catch(Exception exp){
				return;
			}
		}
		else if(e.getSource()==b[7]){
			String name=f[7].getText();
			actorMethods m=new actorMethods();
			//m.inserdata();
			movieNode n= m.all_coactorsView(name);
			File newTextFile=new File("new.txt");
			int a=1;
			try {
				FileWriter fw=new FileWriter(newTextFile);
				  while(n!=null){
					  fw.write(String.valueOf(a));
						fw.write(" : ");
						fw.write(n.actor_1.name);
						fw.write('\n');
						fw.write(n.actor_2.name);
						fw.write('\n');
						fw.write(n.actor_3.name);
						fw.write('\n');
                         	n=n.next;
                         	a++;
					}
				
				//   f[1].setText(null);
				fw.close();
	          JFrame f=new JFrame();
	          f.setLayout(new BorderLayout());
	          JTextArea fe=new JTextArea();
	          fe.setLineWrap(true);
	          fe.setWrapStyleWord(true);
	          JScrollPane sp=new JScrollPane(fe);
	          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	          f.add(sp,BorderLayout.CENTER);
	        
	        FileReader reader=new FileReader("new.txt");
	        BufferedReader br=new BufferedReader(reader);
	        fe.read(br,null);
	         br.close();
	         fe.requestFocus();
	         f.setVisible(true);
	         f.setSize(500,500);
	         
			}catch(Exception exp){
				return;
			}
		}
		else if(e.getSource()==b[5]){
			String name=f[5].getText();
			movieMethod m=new movieMethod();
			//m.inserdata();
			movieNode n= m.searchDirectorView(name);
			File newTextFile=new File("new.txt");
			int a=1;
			try {
				FileWriter fw=new FileWriter(newTextFile);
				  while(n!=null){
					  fw.write(String.valueOf(a));
						fw.write(" : ");
						fw.write(n.movie_title);
						fw.write('\n');
						a++;
                         	n=n.next;
					}
				
				//   f[1].setText(null);
				fw.close();
	          JFrame f=new JFrame();
	          f.setLayout(new BorderLayout());
	          JTextArea fe=new JTextArea();
	          fe.setLineWrap(true);
	          fe.setWrapStyleWord(true);
	          JScrollPane sp=new JScrollPane(fe);
	          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
	          f.add(sp,BorderLayout.CENTER);
	        
	        FileReader reader=new FileReader("new.txt");
	        BufferedReader br=new BufferedReader(reader);
	        fe.read(br,null);
	         br.close();
	         fe.requestFocus();
	         f.setVisible(true);
	         f.setSize(500,500);
	         
			}catch(Exception exp){
				return;
			}
		}


			else if(e.getSource()==b[0]){
				String name=f[0].getText();
				movieMethod m=new movieMethod();
				//m.inserdata();
				movieNode n= m.searchgenreview(name);
				File newTextFile=new File("new.txt");
				int a=1;
				try {
					FileWriter fw=new FileWriter(newTextFile);
					fw.write("Movie Titles");
					fw.write('\n');
					  while(n!=null){
						  fw.write(String.valueOf(a));
							fw.write(" : ");
							fw.write(n.movie_title);
							fw.write('\n');
	                         	n=n.next;
	                         	a++;
						}
					
					//   f[1].setText(null);
					fw.close();
		          JFrame f=new JFrame();
		          f.setLayout(new BorderLayout());
		          JTextArea fe=new JTextArea();
		          fe.setLineWrap(true);
		          fe.setWrapStyleWord(true);
		          JScrollPane sp=new JScrollPane(fe);
		          sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		          f.add(sp,BorderLayout.CENTER);
		        
		        FileReader reader=new FileReader("new.txt");
		        BufferedReader br=new BufferedReader(reader);
		        fe.read(br,null);
		         br.close();
		         fe.requestFocus();
		         f.setVisible(true);
		         f.setSize(500,500);
		         
				}catch(Exception exp){
					return;
				}
			}
			}
		
		}

}
