
public class runner {
public static void main(String args[]){
movieMethod mvl=new movieMethod ();
mvl.inserdata();
actorMethods ac=new actorMethods();
//ac.actorMovies("Chris Hemsworth");
//ac.all_coactors("Leonardo DiCaprio");
//ac.coactors("Avatar");
//ac.actorMovies("Peter Dinklage");
//mvl.searchDirector("Andrew Stanton");
//mvl.searchActor("Johnny Depp");
//mvl.searchrating(6.2,6.3);
//mvl.searchyear(2005);
//mvl.searchgenre("Drama");
//mvl.searchDirector("Sam Mendes");
//mvl.searchActor("Johnny Depp");
//mvl.searchgenre("Music");
//genresNode gn=reading.h.arr[1].root.data.genres.head;
//System.out.println(reading.h.arr[1].root.data.genres.head.genre+"   "+reading.h.arr[1].root.data.genres.head.m.head.movie_title);
//mvl.searchgenre("Film-Noir");
//System.out.println(reading.gl.head.genre+"  "+reading.gl.head.m.head.movie_title);
//movieMethod mm=new movieMethod();
//mvl.searchgenre("Music");
//System.out.println(reading.gl.head.m.head);
//hashing av=reading.h;
//reading.ha.arr[20].traverse();
//System.out.println(av.arr[1].root.data.actor_1.name+"   "+av.arr[1].root.data.actor_1.list.head.next.movie_title);
//actor node=new actor();
//node.coactors("Avatar");
//node.all_coactors("Johnny Depp");
//System.out.println(reading.ha.arr[1].root.list.head.movie_title);
//System.out.println(av.arr[1].root.data.actor_1_fb_likes);
//System.out.println((reading.hd.search("Gore Verbinski").list.head.movie_title));
//hashing h=mvl.h;
//System.out.println("h"+reading.h);
//movieAvlNode mv=reading.h.search("The Lone Ranger�");
//System.out.println(mv.data.director_Name);
//System.out.println(mv.data.director_Name.name+"    "+mv.data.director_Name.list.head.movie_title);
/*hashdirector hd=reading.hd;
 
 */
/*directorNode dn=hd.search("Gore Verbinski");
System.out.println(dn.list);
movieNode md=dn.list.head;
while(md!=null){
	System.out.println(md.movie_title);
	md=md.next;
}
//reading.h.arr[1].traverse();
actor ac=new actor();
ac.coactors("Avatar�");
//ac.all_coactors("CCH Pounder");
/*for(int i=0;i<reading.gen.size();i++){
	System.out.println(reading.gen.get(i));
}
//actor ac=new actor();
//ac.actory("Brad Pitt");
//reading.ha.arr[1].traverse();
*/
}
}