public class plot_keywords {
	 plotNode root;
	 
	    int height(plotNode N) {
	        if (N == null)
	            return 0;
	 
	        return N.height;
	    }
	 
	    int max(int a, int b) {
	    	 if (a > b) 
	 	    	return a;
	 	    else return b;
	    }
public plotNode rightRotate(plotNode y) {
	plotNode x = y.left;
	//System.out.println(x.name);
		plotNode T2 = x.right;
	 
	        x.right = y;
	        y.left = T2;
	 
	     
	        y.height = max(height(y.left), height(y.right)) + 1;
	        x.height = max(height(x.left), height(x.right)) + 1;
	
	    
	        return x;
	    }
	 
	   
plotNode leftRotate(plotNode x) {
	plotNode y = x.right;
	if(y!=null){
		plotNode T2 = y.left;
	 
	        y.left = x;
	        x.right = T2;
	 
	       
	        x.height = max(height(x.left), height(x.right)) + 1;
	        y.height = max(height(y.left), height(y.right)) + 1;
	}
	       
	        return y;
	    }
	 

	    int getBalance(plotNode N) {
	        if (N == null)
	            return 0;
	 
	        return height(N.left) - height(N.right);
	    }
	    public plotNode Node(movies_linkedlist m,String n){
	    	plotNode ac=new plotNode();
	    	ac.m=m;
	    	ac.word=n;
	    	ac.left=null;
	    	ac.right=null;
	    	ac.height=1;
	    	return ac;
	    }
	    public plotNode  insert(movies_linkedlist m,String n){
	    	return root=insert(root,m,n);
	    }
	    plotNode insert(plotNode node,movies_linkedlist m,String n) {
	    	 
	        
	        if (node == null)
	            return (Node(m,n));
	 
	        if (n.compareTo(node.word)<0)
	            node.left = insert(node.left,m,n);
	        else if (n.compareTo(node.word)>0)
	            node.right = insert(node.right,m,n);
	        else 
	            return node;
	 
	      
	        node.height = 1 + max(height(node.left),
	                              height(node.right));
	 
	        int balance = getBalance(node);
	 
	        // If this node becomes unbalanced, then there
	        // are 4 cases Left Left Case
	        if (balance > 1 && n.compareTo(node.word)<0)
	            return rightRotate(node);
	 
	        // Right Right Case
	        if (balance < -1 && n.compareTo(node.word)>0)
	            return leftRotate(node);
	 
	        // Left Right Case
	        if (balance > 1 &&n.compareTo(node.word)>0) {
	            node.left = leftRotate(node.left);
	            return rightRotate(node);
	        }
	 
	        // Right Left Case
	        if (balance < -1 && n.compareTo(node.word)<0) {
	            node.right = rightRotate(node.right);
	            return leftRotate(node);
	        }
	 
	       
	        return node;
	    }
	    public void traverse(){
	    	traverse(root);
	    }
	    public void traverse(plotNode node) {
	        if (node != null) {
	            System.out.println(node.word + " ");
	            traverse(node.left);
	            traverse(node.right);
	        }
	    }
	    public plotNode search(String val){
	    	plotNode temp=root;
	    	String rval=temp.word;
	    	boolean found=false;
	    	while(temp!=null&&!found){
	    		rval=temp.word;
	    		if(val.compareTo(rval)<0){
	    			temp=temp.left;

	    		}
	    		else if(val.compareTo(rval)>0){
	    			temp=temp.right;
	    		}
	    		else
	    			found=true;
	    	}
	    	if(found==false)
	    		return null;
	    	else return temp;
	    }
}