
public class actorNode {
String name;
movies_linkedlist list;
actorNode left;
actorNode right;
int height;

}