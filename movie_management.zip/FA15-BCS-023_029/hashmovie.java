
public class hashmovie {
	public final static int table_size=27;
movieAvlNodeTree[] arr;
hashmovie h;
hashActor ha;
hashmovie(){
	 arr=new movieAvlNodeTree[27];
}

public int getindex(String m){
	//String ind=mv.movie_title;
	char ch=0;
	if(m!=""){
		ch=m.charAt(0);}
	//char ch=m.charAt(0);
	if(ch=='A'||ch=='a')
		return 1;
	if(ch=='B'||ch=='b')
		return 2;
	if(ch=='C'||ch=='c')
		return 3;
	if(ch=='D'||ch=='d')
		return 4;
	if(ch=='E'||ch=='e')
		return 5;
	if(ch=='F'||ch=='f')
		return 6;
	if(ch=='G'||ch=='g')
		return 7;
	if(ch=='H'||ch=='h')
		return 8;
	if(ch=='I'||ch=='i')
		return 9;
	if(ch=='J'||ch=='j')
		return 10;
	if(ch=='K'||ch=='k')
		return 11;
	if(ch=='L'||ch=='l')
		return 12;
	if(ch=='M'||ch=='m')
		return 13;
	if(ch=='N'||ch=='n')
		return 14;
	if(ch=='O'||ch=='o')
		return 15;
	if(ch=='P'||ch=='p')
		return 16;
	if(ch=='Q'||ch=='q')
		return 17;
	if(ch=='R'||ch=='r')
		return 18;
	if(ch=='S'||ch=='s')
		return 19;
	if(ch=='T'||ch=='t')
		return 20;
	if(ch=='U'||ch=='u')
		return 21;
	if(ch=='V'||ch=='v')
		return 22;
	if(ch=='W'||ch=='w')
		return 23;
	if(ch=='X'||ch=='x')
		return 24;
	if(ch=='Y'||ch=='y')
		return 25;
	if(ch=='Z'||ch=='z')
		return 26;
	else return 0;
	}
public int getindex(movieNode mv){
	String ind=mv.movie_title;
	char ch = 0;
	if(ind!=""){
	ch=ind.charAt(0);}
	if(ch=='A'||ch=='a')
		return 1;
	if(ch=='B'||ch=='b')
		return 2;
	if(ch=='C'||ch=='c')
		return 3;
	if(ch=='D'||ch=='d')
		return 4;
	if(ch=='E'||ch=='e')
		return 5;
	if(ch=='F'||ch=='f')
		return 6;
	if(ch=='G'||ch=='g')
		return 7;
	if(ch=='H'||ch=='h')
		return 8;
	if(ch=='I'||ch=='i')
		return 9;
	if(ch=='J'||ch=='j')
		return 10;
	if(ch=='K'||ch=='k')
		return 11;
	if(ch=='L'||ch=='l')
		return 12;
	if(ch=='M'||ch=='m')
		return 13;
	if(ch=='N'||ch=='n')
		return 14;
	if(ch=='O'||ch=='o')
		return 15;
	if(ch=='P'||ch=='p')
		return 16;
	if(ch=='Q'||ch=='q')
		return 17;
	if(ch=='R'||ch=='r')
		return 18;
	if(ch=='S'||ch=='s')
		return 19;
	if(ch=='T'||ch=='t')
		return 20;
	if(ch=='U'||ch=='u')
		return 21;
	if(ch=='V'||ch=='v')
		return 22;
	if(ch=='W'||ch=='w')
		return 23;
	if(ch=='X'||ch=='x')
		return 24;
	if(ch=='Y'||ch=='y')
		return 25;
	if(ch=='Z'||ch=='z')
		return 26;
	else return 0;
	}


public void insert(movieNode mv){
	int index=getindex(mv);
	if(arr[index]==null){
		movieAvlNodeTree mvl=new movieAvlNodeTree();
		mvl.insert(mv);
		arr[index]=mvl;
			}
	else{
	movieAvlNodeTree mk=arr[index];
	mk.insert(mv);
	}
}
public movieAvlNode search(String m){
	int index=getindex(m);
	return arr[index].search(m);
}

public void transverse(){
	for(int i=0;i<27;i++){
		arr[i].traverse();
	}
}

}
