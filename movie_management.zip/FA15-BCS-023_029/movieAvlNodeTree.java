import java.awt.Dimension;
import java.awt.Font;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class movieAvlNodeTree {
	movieAvlNode root;
	hashmovie h;
	movieAvlNodeTree (){
		root=null;
	}
	public int getheight(movieAvlNode N) {
	    if (N == null)
	        return 0;

	    return N.height;
	}

	public int getmax(int a, int b) {
	    if (a > b) 
	    	return a;
	    else return b;
	}


	public int BalanceFactor(movieAvlNode N) {
	    if (N == null)
	        return 0;
		        return getheight(N.left) - getheight(N.right);
	}
	
	
	
	public movieAvlNode newNode(movieNode m){
		//System.out.println("new");
		movieAvlNode node = new movieAvlNode();
		node.data   = m;
	    node.left   = null;
	    node.right  = null;
	    node.height = 1; 
	    return(node);
	}
	public movieAvlNode insert(movieNode val) {
		//System.out.println("root="+val.movie_title);
		
		   return root=insert(root,val);
		   
		   }
		   public movieAvlNode insert(movieAvlNode node,movieNode key)
		   {
			   
		       if (node == null)
		           return(newNode(key));
		    
		       if (key.movie_title.compareTo(node.data.movie_title)<0){
		    	   if(node==null||key==null)
		    	   System.out.println("null");
		          //if(node.left!=null&&key!=null){
		    		   //System.out.println("null");
		    	   //System.out.println(node.left.data.movie_title);
		           node.left  = insert(node.left, key);}
		       else if (key.movie_title.compareTo(node.data.movie_title)>0){
		    		   if(node==null||key==null)
		    			   System.out.println("its null");
		           node.right = insert(node.right, key);
		    		   }
		       else 
		           return node;
		    
		       node.height = 1 + getmax(getheight(node.left),
		                              getheight(node.right));
		    
		
		       int balance = BalanceFactor(node);
		    
		         // Left Left / right rotation
		       if (balance > 1 && (key.movie_title.compareTo(node.left.data.movie_title)<0))
		           return rightRotate(node);
		    
		       // Right Right / left rotaion
		       if (balance < -1 && (key.movie_title.compareTo(node.right.data.movie_title)>0))
		           return leftRotate(node);
		    
		       // Left Right Case
		       if (balance > 1 && (key.movie_title.compareTo(node.left.data.movie_title)>0))
		       {
		    	  if(node==null)
		    		  System.out.println("its null");
		           node.left =  leftRotate(node.left);
		           return rightRotate(node);
		       }
		    
		       // Right Left Case
		       if (balance < -1 && (key.movie_title.compareTo(node.right.data.movie_title)<0))
		       {
		           node.right = rightRotate(node.right);
		           return leftRotate(node);
		       }
		    
		       return node;
		   }
		  
		   public movieAvlNode leftRotate(movieAvlNode x)
		   { 
			   movieAvlNode y = x.right;
			   if(y==null)
				   System.out.println("it is null");
			   movieAvlNode T2 = y.left;
		    
		       y.left = x;
		       x.right = T2;
		    
		       x.height = getmax(getheight(x.left), getheight(x.right))+1;
		       y.height = getmax(getheight(y.left), getheight(y.right))+1;

		       return y;
		   }
	
		   public movieAvlNode rightRotate(movieAvlNode y)
		   {
			   movieAvlNode x = y.left;
			   movieAvlNode T2 = x.right;
		    
		       x.right = y;
		       y.left = T2;
		   
		       y.height = getmax(getheight(y.left), getheight(y.right))+1;
		       x.height = getmax(getheight(x.left), getheight(x.right))+1;
		    
		       return x;
		   }
		    
	public movieAvlNode search(String val) {
	   return search(root,val);
	   }

	 private movieAvlNode search(movieAvlNode node,String val){
	       boolean found = false;
	       
	     while ((node != null) && !found){
	       String rval = node.data.movie_title;
	       if (val.compareTo(rval)<0)
	    	   node = node.left;
	       else if (val.compareTo(rval)>0)
	    	   node = node.right;
	         else
	         {
	             found = true;
	             break;
	         }
	             }
	     return node;
	 }
	 public void traverseByRating(double min,double max){
		 traverseByRating(root,min,max);
	 }
	 void traverseByRating(movieAvlNode node,double min,double max)
	    {
	        if (node == null)
	            return;
	       // System.out.println("ye"+node.data.title_year);
if(node.data.idmb_score>=min&&node.data.idmb_score<=max){
	        System.out.println(node.data.movie_title);
}
	        traverseByRating(node.left,min,max);
	 
	        traverseByRating(node.right,min,max);
	    }
	 public void traverse(){
		 traverse(root);
	 }
	 public void traverseByYear(int y){
		 traverseByYear(root,y);
	 }
	 void traverseByYear(movieAvlNode node,int y)
	    {
	        if (node == null)
	            return;
	       // System.out.println("ye"+node.data.title_year);
if(node.data.title_year==y){
	        System.out.println(node.data.movie_title);
}
	        traverseByYear(node.left,y);
	 
	        traverseByYear(node.right,y);
	    }

	 void traverse(movieAvlNode node)
	    {
	        if (node == null)
	            return;

	        System.out.println(node.data.movie_title);
	 
	        traverse(node.left);
	 
	        traverse(node.right);
	    }
	

	
}
