
public class hashdirector {
	private final static int table_size=27;
	directorAvlTree[] arr;
	hashdirector(){
		 arr=new directorAvlTree[table_size];
	}

	public int getindex(String m){
		char ch=0;
		//System.out.println(m);
		if(m!=""&&m!=null&&m.length()>0){
			ch=m.charAt(0);
		}	
		if(ch=='A'||ch=='a')
			return 1;
			
		if(ch=='B'||ch=='b')
			return 2;
		if(ch=='C'||ch=='c')
			return 3;
		if(ch=='D'||ch=='d')
			return 4;
		if(ch=='E'||ch=='e')
			return 5;
		if(ch=='F'||ch=='f')
			return 6;
		if(ch=='G'||ch=='g')
			return 7;
		if(ch=='H'||ch=='h')
			return 8;
		if(ch=='I'||ch=='i')
			return 9;
		if(ch=='J'||ch=='j')
			return 10;
		if(ch=='K'||ch=='k')
			return 11;
		if(ch=='L'||ch=='l')
			return 12;
		if(ch=='M'||ch=='m')
			return 13;
		if(ch=='N'||ch=='n')
			return 14;
		if(ch=='O'||ch=='o')
			return 15;
		if(ch=='P'||ch=='p')
			return 16;
		if(ch=='Q'||ch=='q')
			return 17;
		if(ch=='R'||ch=='r')
			return 18;
		if(ch=='S'||ch=='s')
			return 19;
		if(ch=='T'||ch=='t')
			return 20;
		if(ch=='U'||ch=='u')
			return 21;
		if(ch=='V'||ch=='v')
			return 22;
		if(ch=='W'||ch=='w')
			return 23;
		if(ch=='X'||ch=='x')
			return 24;
		if(ch=='Y'||ch=='y')
			return 25;
		if(ch=='Z'||ch=='z')
			return 26;
		else
		{
			return 0;
			}
		}
	public void insert(movies_linkedlist mv,String n){
		int index=getindex(n);
	
		if(arr[index]==null){
	
			directorAvlTree mvl=new directorAvlTree();
			mvl.insert(mv, n);
				arr[index]=mvl;
				}
		else{
			
			directorAvlTree  mk=arr[index];
			//System.out.println(mk.node.name);
		mk.insert(mv,n);
		
		}
		
	}
	public directorNode search(String m){
		int index=getindex(m);
		return arr[index].search(m);
	}

	public void transverse(){
		
		for(int i=0;i<27;i++){
			if(arr[i]!=null){
			arr[i].traverse();
		}}
	}
}
